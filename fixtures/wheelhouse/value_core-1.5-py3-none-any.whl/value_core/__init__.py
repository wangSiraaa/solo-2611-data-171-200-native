__version__ = '1.5'
NAME = 'value-core'
