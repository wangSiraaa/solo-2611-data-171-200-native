__version__ = '1.0'
NAME = 'view-lib'
