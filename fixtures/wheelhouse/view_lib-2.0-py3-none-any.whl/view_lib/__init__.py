__version__ = '2.0'
NAME = 'view-lib'
