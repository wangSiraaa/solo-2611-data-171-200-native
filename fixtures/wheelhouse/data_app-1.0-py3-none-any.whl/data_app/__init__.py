__version__ = '1.0'
NAME = 'data-app'
