__version__ = '1.0'
NAME = 'audit-lib'
