__version__ = '1.0'
NAME = 'theme-addon'
